$(document).ready(function(){
    $(".openbs").click(function(){
	$(".envbuttons").collapse('show');
    });
    $(".closebs").click(function(){
	$(".envbuttons").collapse('hide');
    });

});
