function showhidemenu() {
    $(".leftmenu").toggle();
    $(".sidenav").toggleClass("normalwidth extendedwidth");
    $(".main").toggleClass("normalmargin extendedmargin");
}

